import apis from "./apis";
export{
    apis
}