const imageURL = (pathOrName = '') => `${process.env.PUBLIC_URL}/images/${pathOrName}`;

export default imageURL